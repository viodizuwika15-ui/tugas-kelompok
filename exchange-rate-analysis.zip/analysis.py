import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv('exchange_rates.csv', parse_dates=['date'])

print("Ringkasan data:")
print(df.head())

pivot = df.pivot(index='date', columns='currency', values='rate_to_usd')
print("\nStatistik Deskriptif:")
print(pivot.describe())

plt.figure()
pivot.plot(title='Exchange Rate vs USD')
plt.xlabel('Date')
plt.ylabel('Rate to USD')
plt.savefig('exchange_rate_plot.png')
print("\nPlot saved as exchange_rate_plot.png")
