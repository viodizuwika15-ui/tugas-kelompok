# Exchange Rate Analysis

This project analyzes currency exchange rates against USD using Python, pandas, and matplotlib.

Files:
- `exchange_rates.csv` — sample dataset
- `analysis.py` — script to analyze and plot exchange rates
